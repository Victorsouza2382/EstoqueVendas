<?php 


include_once "../../classes/conexao.php";
include_once "../../classes/clientes.php";

$id = $_POST['idcliente'];

$obj = new clientes();
echo $obj->excluirCliente($id);

?>