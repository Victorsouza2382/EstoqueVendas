<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

<link rel="stylesheet" type="text/css" href="../style/alertifyjs/css/alertify.css">
<link rel="stylesheet" type="text/css" href="../style/alertifyjs/css/themes/default.css">
<link rel="stylesheet" type="text/css" href="../style/bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="../style/select2/css/select2.css">
<link rel="stylesheet" type="text/css" href="../css/menu.css">
<link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
<script src="https://kit.fontawesome.com/778c80b037.js" crossorigin="anonymous"></script>


<script src="../style/jquery-3.2.1.min.js"></script>
<script src="../style/alertifyjs/alertify.js"></script>
<script src="../style/bootstrap/js/bootstrap.js"></script>
<script src="../style/select2/js/select2.js"></script>
<script src="../js/funcoes.js"></script>
